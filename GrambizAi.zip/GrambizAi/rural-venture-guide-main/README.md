# GramBiz Compass

Create a modern, responsive AI-powered web application named “GramBiz AI” for SIH 26091. The app helps rural users decide which business to start and where to start it using location, local demand, competition, investment, market trends, and nearby shop/rent data. Include an AI chatbot, Hindi/English language support, business recommendations, location analysis with maps, investment/profit estimation, competition prediction, market analysis, and nearby rental-shop listings. Use a clean, simple UI suitable for rural users, with an attractive dashboard and mobile-first design.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```